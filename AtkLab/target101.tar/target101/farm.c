/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_310()
{
    return 3284650312U;
}

unsigned getval_370()
{
    return 3284633928U;
}

void setval_212(unsigned *p)
{
    *p = 2421695790U;
}

unsigned getval_340()
{
    return 3284633928U;
}

unsigned getval_356()
{
    return 3284634056U;
}

unsigned addval_406(unsigned x)
{
    return x + 3281031256U;
}

void setval_116(unsigned *p)
{
    *p = 3281031240U;
}

void setval_304(unsigned *p)
{
    *p = 2425411668U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_457(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_305()
{
    return 3281046145U;
}

void setval_313(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_231()
{
    return 3674789513U;
}

void setval_337(unsigned *p)
{
    *p = 3380920717U;
}

void setval_322(unsigned *p)
{
    *p = 96982665U;
}

void setval_385(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_342()
{
    return 3353381192U;
}

unsigned getval_157()
{
    return 3230976649U;
}

void setval_191(unsigned *p)
{
    *p = 3529556361U;
}

unsigned addval_213(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_485(unsigned x)
{
    return x + 3269495112U;
}

void setval_476(unsigned *p)
{
    *p = 3374367105U;
}

unsigned addval_371(unsigned x)
{
    return x + 3674784136U;
}

void setval_432(unsigned *p)
{
    *p = 3532964233U;
}

unsigned addval_334(unsigned x)
{
    return x + 3246992933U;
}

void setval_388(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_177()
{
    return 3531915657U;
}

unsigned addval_470(unsigned x)
{
    return x + 3223377545U;
}

unsigned addval_399(unsigned x)
{
    return x + 3526940301U;
}

unsigned getval_249()
{
    return 3525364365U;
}

void setval_151(unsigned *p)
{
    *p = 3675835017U;
}

unsigned getval_179()
{
    return 3600380336U;
}

unsigned getval_236()
{
    return 3527988873U;
}

unsigned getval_242()
{
    return 2425542281U;
}

unsigned getval_421()
{
    return 3523794633U;
}

void setval_452(unsigned *p)
{
    *p = 2447411528U;
}

void setval_139(unsigned *p)
{
    *p = 3223374473U;
}

unsigned getval_253()
{
    return 2429192656U;
}

void setval_279(unsigned *p)
{
    *p = 3372794121U;
}

unsigned getval_158()
{
    return 3374893705U;
}

unsigned addval_403(unsigned x)
{
    return x + 935447177U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
